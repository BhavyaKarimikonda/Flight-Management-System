﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Flight_BK
    {
        public int ID { get; set; }
        public string Destination { get; set; }
        public string GateNo { get; set; }
        //  public int DepartureId { get; set; }
        public int StatusId { get; set; }
        public int TerminalId { get; set; }
        public string Name { get; set; }
        public FlightDeparture_BK departure = new FlightDeparture_BK();
    }


    public class FlightDeparture_BK
    {
        public int ID { get; set; }
        public DateTime? Scheduled { get; set; }
        public DateTime? Estimated { get; set; }
        public DateTime? Actual { get; set; }
    }


    public class FlightStatus_BK
    {
        //  public int ID { get; set; }
        public string Description { get; set; }
    }

    public class FlightOperators_BK
    {
        //   public int ID { get; set; }
        public string Name { get; set; }
        public string HeadOffice { get; set; }
        public string ContactNo { get; set; }
    }

    public class AirportTerminal_BK
    {
        //  public int ID { get; set; }
        public string TerminalName { get; set; }
        public string AirportName { get; set; }
        public string ContactNo { get; set; }
    }
}
