﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FlightException;
using BL;


namespace WPF
{
    /// <summary>
    /// Interaction logic for DeleteFlight.xaml
    /// </summary>
    public partial class DeleteFlight : Window
    {
        public DeleteFlight()
        {
            InitializeComponent();
        }

        private void BtnDeleteFlight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool employeeAdded = FlightBL.DeleteFlightBL(Convert.ToInt32(txtFlightId.Text));
                if (employeeAdded)
                {
                    MessageBox.Show("Flight Deleted");

                }
                else
                    MessageBox.Show("Flight could not be Deleted");
            }
            catch (FtException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
