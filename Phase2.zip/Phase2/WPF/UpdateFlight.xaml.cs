﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data.Sql;
using FlightException;
using Entity;
using BL;
namespace WPF
{
    /// <summary>
    /// Interaction logic for UpdateFlight.xaml
    /// </summary>
    public partial class UpdateFlight : Window
    {
        public UpdateFlight()
        {
            SqlConnection sqlConnection = new SqlConnection("data source=NDAMSSQL\\SQLILEARN;initial catalog=Training_13Aug19_Pune;persist security info=True;user id=sqluser;password = sqluser");
            InitializeComponent();
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand("Select TerminalName from AirportTerminal_bk", sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                cmbTerminal.Items.Add(reader[0]);
            }
            reader.Close();
            //-------------
            SqlCommand sqlCommand1 = new SqlCommand("Select Description from FlightStatus_bk", sqlConnection);
            SqlDataReader reader1 = sqlCommand1.ExecuteReader();
            while (reader1.Read())
            {
                cmbStatus.Items.Add(reader1[0]);
            }
            reader1.Close();
            //---------------
            SqlCommand sqlCommand2 = new SqlCommand("Select Name from FlightOperators_bk", sqlConnection);
            SqlDataReader reader2 = sqlCommand2.ExecuteReader();
            while (reader2.Read())
            {
                cmbName.Items.Add(reader2[0]);
            }
            reader2.Close();
            sqlConnection.Close();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void BtnUpdateFlight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Flight_BK newFlight = new Flight_BK();
                newFlight.ID = Convert.ToInt32(txtFlightNo.Text);
                newFlight.Destination = txtDestination.Text;
                newFlight.GateNo = txtGateNo.Text;
                newFlight.Name = cmbName.Text;
                newFlight.StatusId = cmbStatus.SelectedIndex + 200;
                newFlight.TerminalId = cmbTerminal.SelectedIndex + 400;
                newFlight.departure.Actual = dpActual.SelectedDate;
                newFlight.departure.Estimated = dpEstimated.SelectedDate;
                newFlight.departure.Scheduled = dpScheduled.SelectedDate;
                bool employeeAdded = FlightBL.UpdateFlightBL(newFlight);
                if (employeeAdded)
                {
                    MessageBox.Show("Flight Updated");
                    
                }
                else
                    MessageBox.Show("Flight could not be Updated");
            }
            catch (FtException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
   
        }

        private void TxtFlightNo_TextChanged(object sender, TextChangedEventArgs e)
        {
                try
                {
                    SqlConnection sqlConnection = new SqlConnection("data source=NDAMSSQL\\SQLILEARN;initial catalog=Training_13Aug19_Pune;persist security info=True;user id=sqluser;password = sqluser");
                    sqlConnection.Open();
                    SqlCommand sqlCommand = new SqlCommand($"Select * from Flight_bk where ID={Convert.ToInt32(txtFlightNo.Text)}", sqlConnection);
                    SqlDataReader reader = sqlCommand.ExecuteReader();
                    reader.Read();
                    Flight_BK newFlight = new Flight_BK();
                    newFlight.Name = reader[1].ToString();
                    newFlight.Destination = reader[2].ToString();
                    newFlight.departure.ID = Convert.ToInt32(reader[3]);
                    newFlight.TerminalId = Convert.ToInt32(reader[4]);
                    newFlight.GateNo = reader[5].ToString();
                    newFlight.StatusId = Convert.ToInt32(reader[6]);
                    reader.Close();

                    SqlCommand sqlcom2 = new SqlCommand($"Select * from FlightDeparture_bk where ID={newFlight.departure.ID}", sqlConnection);
                    SqlDataReader reader2 = sqlcom2.ExecuteReader();
                    reader2.Read();
                    newFlight.departure.Scheduled = DateTime.Parse(reader2[1].ToString());
                    newFlight.departure.Estimated = DateTime.Parse(reader2[2].ToString());
                    newFlight.departure.Actual = DateTime.Parse(reader2[3].ToString());
                    reader2.Close();
                    sqlConnection.Close();

                    txtDestination.Text = newFlight.Destination;
                    txtGateNo.Text = newFlight.GateNo;
                    cmbName.Text = newFlight.Name;
                    cmbStatus.SelectedIndex = newFlight.StatusId - 200;
                    cmbTerminal.SelectedIndex = newFlight.TerminalId - 400;
                    dpActual.SelectedDate = newFlight.departure.Actual;
                    dpEstimated.SelectedDate = newFlight.departure.Estimated;
                    dpScheduled.SelectedDate = newFlight.departure.Scheduled;
                }
                catch (FtException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (SystemException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            
            //this.Close();
        }
    }
    
}
