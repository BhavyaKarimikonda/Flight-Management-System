﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using fs_entity;
using fs_exceptions;


namespace fs_dal
{
    public class Dal
    {
        public static List<Flight> flightList = new List<Flight>();

        public static bool Insert(Flight ft)
        {
            bool added = false;
            try
            {
                flightList.Add(ft);
                added = true;
            }
            catch (Exception ex)
            {
                throw new fsException(ex.Message);
            }
            return added;
        }

        public static List<Flight> GetAllFlights()
        {
            return flightList;
        }

        public static Flight SearchFlight(string flightNo)
        {
            Flight search = null;
            try
            {
                search = flightList.Find(ft => ft.FlightNo == flightNo );
            }
            catch (SystemException ex)
            {
                throw new fsException(ex.Message);
            }
            return search;
        }


        public static bool Update(Flight ft)
        {
            bool updated = false;
            try
            {
                for (int i = 0; i < flightList.Count; i++)
                {
                    if (flightList[i].FlightNo == ft.FlightNo)
                    {
                        flightList[i].FlightName = ft.FlightName;
                        flightList[i].Destination = ft.Destination;
                        flightList[i].departure.Scheduled = ft.departure.Scheduled;
                        flightList[i].departure.Estimated = ft.departure.Estimated;
                        flightList[i].departure.Actual = ft.departure.Actual;
                        flightList[i].Terminal = ft.Terminal;
                        flightList[i].Status = ft.Status;
                        flightList[i].GateNo = ft.GateNo;
                        updated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new fsException(ex.Message);
            }
            return updated;
        }


        public static bool Delete(string flightNo)
        {
            bool deleted = false;
            try
            {
                Flight deleteFlight = flightList.Find(ft => ft.FlightNo == flightNo);

                if (deleteFlight != null)
                {
                    flightList.Remove(deleteFlight);
                    deleted = true;
                }
            }
            catch (fsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return deleted;
        }


    }
}
