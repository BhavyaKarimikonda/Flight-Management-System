﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fs_entity
{
    
    public class Flight
    {
        public string FlightName { get; set; }
        public string FlightNo { get; set; }
        public string Destination { get; set; }
        public Departure departure = new Departure();
        public string Terminal { get; set; }
        public string GateNo { get; set; }
        public string Status { get; set; }
    }

    public class Departure
    {
        public DateTime Scheduled { get; set; }
        public DateTime Estimated { get; set; }
        public DateTime Actual { get; set; }
    }
}
