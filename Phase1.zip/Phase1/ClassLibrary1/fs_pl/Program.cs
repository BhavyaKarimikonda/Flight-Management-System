﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using fs_bl;
using fs_entity;
using fs_exceptions;

namespace fs_pl
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        InsertFtPL();
                        break;
                    case 2:
                        ListAllFtPL();
                        break;
                    case 3:
                        SearchFtPL();
                        break;
                    case 4:
                        UpdateFtPL();
                        break;
                    case 5:
                        DeleteFtPL();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);

        }

        private static void InsertFtPL()
        {
            try
            {
                Flight em = new Flight();
                Console.WriteLine("Enter FlightNo : (Should be in AB1234 format) :");
                em.FlightNo = Console.ReadLine();
                Console.WriteLine("Enter Flight Name : (Should be AirIndia or Indigo or GoAir) :");
                em.FlightName = Console.ReadLine();
                Console.WriteLine("Enter Destination: ");
                em.Destination = Console.ReadLine();
                Console.WriteLine("Enter Terminal:");
                em.Terminal = Console.ReadLine();
                Console.WriteLine("Enter GateNo: ");
                em.GateNo = Console.ReadLine();
                Console.WriteLine("Enter Status: ");
                em.Status = Console.ReadLine();
                Console.WriteLine("Enter scheduled departure:");
                em.departure.Scheduled = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter expected departure:");
                em.departure.Estimated = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter Actual departure");
                em.departure.Actual = DateTime.Parse(Console.ReadLine());

                bool emAdded = Bl.InsertFt(em);
                if (emAdded)
                    Console.WriteLine(" Flight Added");
                else
                    Console.WriteLine(" Flight not Added");
            }
            catch (fsException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchFtPL()
        {
            try
            {
                string flightNo;
                Console.WriteLine("Enter Flight Number to Search:");
                flightNo = Console.ReadLine();
                Flight em = Bl.Searchft(flightNo);
                if (em != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("FlightNo\t\tFlightName\t\tDestination\t\tGateNo\t\tStatus\t\tTerminal\t\tScheduled Time");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}", em.FlightNo, em.FlightName, em.Destination, em.GateNo, em.Status, em.Terminal, em.departure.Scheduled);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Flight Details Available");
                }

            }
            catch (fsException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateFtPL()
        {
            try
            {
                string flightNo;
                Console.WriteLine("Enter Flight Number to Update Details:");
                flightNo = Console.ReadLine();
                Flight updatedFlight = Bl.Searchft(flightNo);
                if (updatedFlight != null)
                {
                    Console.WriteLine("Update Flight Name :");
                    updatedFlight.FlightName = Console.ReadLine();
                    Console.WriteLine("Update Destination :");
                    updatedFlight.Destination = Console.ReadLine();
                    Console.WriteLine("Update terminal :");
                    updatedFlight.Terminal = Console.ReadLine();
                    Console.WriteLine("Update GateNo :");
                    updatedFlight.GateNo = Console.ReadLine();
                    Console.WriteLine("Update Status :");
                    updatedFlight.Status = Console.ReadLine();
                    Console.WriteLine("Update scheduled departure :");
                    updatedFlight.departure.Scheduled = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Update estimated departure :");
                    updatedFlight.departure.Estimated = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Update actual departure :");
                    updatedFlight.departure.Actual = DateTime.Parse(Console.ReadLine());
                    bool FlightUpdated = Bl.Updateft(updatedFlight);
                    if (FlightUpdated)
                        Console.WriteLine("Flight Details Updated");
                    else
                        Console.WriteLine("Flight Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Flight Details Available");
                }
            }
            catch (fsException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void DeleteFtPL()
        {
            try
            {
                string deleteID;
                Console.WriteLine("Enter flightNo to Delete:");
                deleteID = Console.ReadLine();
                Flight deleteFlight = Bl.Searchft(deleteID);
                if (deleteFlight != null)
                {
                    bool Flightdeleted = Bl.Deleteft(deleteID);
                    if (Flightdeleted)
                        Console.WriteLine("Flight Deleted");
                    else
                        Console.WriteLine("Flight not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Flight Details Available");
                }
            }
            catch (fsException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllFtPL()
        {
            try
            {
                List<Flight> emList = Bl.GetAllft();
                if (emList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("FlightNo\t\tFlightName\t\tDestination\t\tGateNo\t\tStatus\t\tTerminal\t\tScheduled Time");
                    Console.WriteLine("******************************************************************************");
                    foreach (Flight em in emList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}", em.FlightNo, em.FlightName, em.Destination, em.GateNo, em.Status, em.Terminal, em.departure.Scheduled);
                    }
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Flight Details Available");
                }
            }
            catch (fsException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Flight Management System***********");
            Console.WriteLine("1. Add Flight");
            Console.WriteLine("2. List All Flights");
            Console.WriteLine("3. Search Flight by ID");
            Console.WriteLine("4. Update Flight");
            Console.WriteLine("5. Delete Flight");
            Console.WriteLine("6. Exit");
            Console.WriteLine("******************************************\n");

        }
    }
}
