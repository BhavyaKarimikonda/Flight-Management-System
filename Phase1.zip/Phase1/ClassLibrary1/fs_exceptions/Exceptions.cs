﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fs_exceptions
{
    public class fsException:ApplicationException
    {
        public fsException(string message): base(message)
        {

        }
    }
}
