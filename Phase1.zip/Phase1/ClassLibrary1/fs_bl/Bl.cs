﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using fs_dal;
using fs_entity;
using fs_exceptions;
using System.Text.RegularExpressions;

namespace fs_bl
{
    public class Bl
    {
        public static bool ValidateFt(Flight ft)
        {
            StringBuilder sb = new StringBuilder();
            bool valid = true;
            string[] flightNames = { "AirIndia", "Indigo", "GoAir" };
            string[] statusNames = { "OnTime", "Delayed", "Cancelled", "Expected", "Arrived", "Check-In", "Boarding", "GateClosed", "Departed" };

            if (!Regex.IsMatch(ft.FlightNo, "^[A-Z]{2}[0-9]{4}$"))
            {
                valid = false;
                sb.Append(Environment.NewLine + "7 characters with first 2 characters upper case letters followed by hyphen and then 4 digits");
            }
            if (!flightNames.Contains(ft.FlightName))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Flight Name should be AirIndia or Indigo or GoAir");
            }

            if(!Regex.IsMatch(ft.Destination,"^[A-Za-z]+$"))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Destination should be string");
            }


            //if (!flightNames.Contains(ft.Destination))
            //{
            //    valid = false;
            //    sb.Append(Environment.NewLine + "Flight destination should be AirIndia or Indigo or GoAir");

            //}

            if(ft.departure.Estimated == null || ft.departure.Scheduled ==null || ft.departure.Actual ==null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Departure can't be null");
            }

            if(ft.departure.Estimated < DateTime.Now || ft.departure.Actual < DateTime.Now || ft.departure.Scheduled < DateTime.Now)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Departure(s) can't be less than present day");
            }

            if (ft.departure.Scheduled > ft.departure.Actual || ft.departure.Scheduled > ft.departure.Estimated)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Scheduled can't be greater than Actual and Estimated departures");
            }


            if (!Regex.IsMatch(ft.Terminal, "^[A-Za-z]+$"))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Terminal Name should be string");
            }

            if (!Regex.IsMatch(ft.GateNo, "^[0-9]+$"))
            {
                valid = false;
                sb.Append(Environment.NewLine + "GateNo should be number");
            }

            if (!statusNames.Contains(ft.Status))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Status should be OnTime , Delayed, Cancelled, Expected, Arrived, Check-In, Boarding, GateClosed or Departed");
            }

           if (valid == false)
              throw new fsException(sb.ToString());
            return valid;
        }

        public static bool InsertFt(Flight ft)
        {
            bool flightAdded = false;
            try
            {
                if (ValidateFt(ft))
                {
                    flightAdded = Dal.Insert(ft);
                }
            }
            catch (fsException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return flightAdded;
        }

        public static List<Flight> GetAllft()
        {
            List<Flight> ftList = null;
            try
            {
                ftList = Dal.GetAllFlights();
            }
            catch (fsException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ftList;
        }


        public static Flight Searchft(string flightNo)
        {
            Flight search_ft = null;
            try
            {
                search_ft = Dal.SearchFlight(flightNo);
            }
            catch (fsException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return search_ft;
        }

        public static bool Updateft(Flight ft)
        {
            bool updated = false;
            try
            {
                if (ValidateFt(ft))
                {
                    updated = Dal.Update(ft);
                }
            }
            catch (fsException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return updated;
        }


        public static bool Deleteft(string flightNo)
        {
            bool deleted = false;
            try
            {
                if (flightNo != null)
                {
                    deleted = Dal.Delete(flightNo);
                }
                else
                {
                    throw new fsException("Invalid flight Number");
                }
            }
            catch (fsException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return deleted;
        }

    }
}
