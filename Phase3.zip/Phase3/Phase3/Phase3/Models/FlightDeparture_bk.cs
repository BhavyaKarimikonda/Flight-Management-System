namespace Phase3.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class FlightDeparture_bk
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public FlightDeparture_bk()
        {
            Flight_bk = new HashSet<Flight_bk>();
        }

        public int ID { get; set; }

        public DateTime Scheduled { get; set; }

        public DateTime Estimated { get; set; }

        public DateTime Actual { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Flight_bk> Flight_bk { get; set; }
    }
}
