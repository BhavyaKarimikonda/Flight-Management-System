﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Phase3.Models
{
    public class FlightMetadata
    {

        [Required(ErrorMessage = "Designation cannot be empty")]
        [RegularExpression("^[a-zA-Z]", ErrorMessage = "Invalid Destination")]
        public int Destination{ get; set; }

        [Required(ErrorMessage = "GateNo cannot be empty")]
        [RegularExpression("[0-9]{3}", ErrorMessage = "Invalid ID")]
        public int GateNo { get; set; }
    }
}