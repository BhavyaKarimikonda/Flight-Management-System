namespace Phase3.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<AirportTerminal_bk> AirportTerminal_bk { get; set; }
        public virtual DbSet<Flight_bk> Flight_bk { get; set; }
        public virtual DbSet<FlightDeparture_bk> FlightDeparture_bk { get; set; }
        public virtual DbSet<FlightOperators_bk> FlightOperators_bk { get; set; }
        public virtual DbSet<FlightStatus_bk> FlightStatus_bk { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AirportTerminal_bk>()
                .Property(e => e.TerminalName)
                .IsUnicode(false);

            modelBuilder.Entity<AirportTerminal_bk>()
                .Property(e => e.AiportName)
                .IsUnicode(false);

            modelBuilder.Entity<AirportTerminal_bk>()
                .Property(e => e.ContactNo)
                .IsUnicode(false);

            modelBuilder.Entity<AirportTerminal_bk>()
                .HasMany(e => e.Flight_bk)
                .WithOptional(e => e.AirportTerminal_bk)
                .HasForeignKey(e => e.TerminalId);

            modelBuilder.Entity<Flight_bk>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<Flight_bk>()
                .Property(e => e.Destination)
                .IsUnicode(false);

            modelBuilder.Entity<Flight_bk>()
                .Property(e => e.GateNo)
                .IsUnicode(false);

            modelBuilder.Entity<FlightDeparture_bk>()
                .HasMany(e => e.Flight_bk)
                .WithOptional(e => e.FlightDeparture_bk)
                .HasForeignKey(e => e.DepartureId);

            modelBuilder.Entity<FlightOperators_bk>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<FlightOperators_bk>()
                .Property(e => e.HeadOffice)
                .IsUnicode(false);

            modelBuilder.Entity<FlightOperators_bk>()
                .Property(e => e.ContactNo)
                .IsUnicode(false);

            modelBuilder.Entity<FlightStatus_bk>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<FlightStatus_bk>()
                .HasMany(e => e.Flight_bk)
                .WithOptional(e => e.FlightStatus_bk)
                .HasForeignKey(e => e.StatusId);
        }
    }
}
