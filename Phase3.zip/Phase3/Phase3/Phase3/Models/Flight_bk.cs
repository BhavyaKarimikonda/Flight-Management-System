namespace Phase3.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Flight_bk
    {
        public int ID { get; set; }

        [StringLength(50)]
        public string Name { get; set; }

        [Required]
        [StringLength(30)]
        public string Destination { get; set; }

        public int? DepartureId { get; set; }

        public int? TerminalId { get; set; }

        [Required]
        [StringLength(30)]
        public string GateNo { get; set; }

        public int? StatusId { get; set; }

        public virtual AirportTerminal_bk AirportTerminal_bk { get; set; }

        public virtual FlightDeparture_bk FlightDeparture_bk { get; set; }

        public virtual FlightStatus_bk FlightStatus_bk { get; set; }
    }
}
