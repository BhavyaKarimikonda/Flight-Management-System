﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Phase3.Models
{
    [System.ComponentModel.DataAnnotations.MetadataType(typeof(FlightMetadata))]
    public class FlightPartial
    {
    }
}