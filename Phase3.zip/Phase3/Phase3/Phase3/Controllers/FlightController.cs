﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Phase3.Models;
using System.Data.Entity;
using System.Net;

namespace Phase3.Controllers
{
    public class FlightController : Controller
    {
        private Model1 db = new Model1();

        public ActionResult Home()
        {
            return View();
        }
        // GET: Flight
        public ActionResult Index()
        {
            var flights = db.Flight_bk.Include(a => a.FlightDeparture_bk).Include(b => b.FlightStatus_bk);
            return View(flights.ToList());
        }

        [HttpPost]
        public ActionResult Create([Bind(Include = "Name, Destination,TerminalId, GateNo,StatusId")] Flight_bk flight, [Bind(Include = "Scheduled, Estimated, Actual")] FlightDeparture_bk departure)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    departure.Scheduled = DateTime.Now;
                    departure.Estimated = DateTime.Now;
                    departure.Actual = DateTime.Now;
                    db.FlightDeparture_bk.Add(departure);
                    flight.DepartureId = departure.ID;
                    db.Flight_bk.Add(flight);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                
                ViewBag.Name = new SelectList(db.FlightOperators_bk, "Name", "Name");
                ViewBag.TerminalId = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName");
                ViewBag.StatusId = new SelectList(db.FlightStatus_bk, "ID", "Description");
                return View(flight);
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public ActionResult Create()
        {
            ViewBag.Name = new SelectList(db.FlightOperators_bk, "Name", "Name");
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName");
            ViewBag.StatusId = new SelectList(db.FlightStatus_bk, "ID", "Description");
            return View();
        }


        public ActionResult Edit(int ID)
        {
            if (ID == 0)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_bk flight = db.Flight_bk.Find(ID);
            if (flight == null)
            {
                return HttpNotFound();
            }
            ViewBag.Name = new SelectList(db.FlightOperators_bk, "ID", "Name",flight.Name);
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName",flight.TerminalId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_bk, "ID", "Description",flight.StatusId);
            return View(flight);
        }


        [HttpPost]
        public ActionResult Edit([Bind(Include = "ID, Name, Destination,TerminalId, GateNo,StatusId")]Flight_bk flight, [Bind(Include = "Scheduled, Estimated, Actual")] FlightDeparture_bk departure)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.Entry(flight).State = EntityState.Modified;
                    departure.Scheduled = DateTime.Now;
                    departure.Estimated = DateTime.Now;
                    departure.Actual = DateTime.Now;

                    db.FlightDeparture_bk.Add(departure); 
                    flight.DepartureId = departure.ID;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.Name = new SelectList(db.FlightOperators_bk, "ID", "Name", flight.Name);
                ViewBag.TerminalId = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName", flight.TerminalId);
                ViewBag.StatusId = new SelectList(db.FlightStatus_bk, "ID", "Description", flight.StatusId);
                return View(flight);
            }
            catch (Exception)
            {
                return View();
            }
        }


        public ActionResult Search(string ID)
        {
            if (ID != null)
            {
                int flightID = Convert.ToInt32(ID);
                List<Flight_bk> flight = null;
                flight = db.Flight_bk.Where(x => x.ID == flightID).ToList();
                if (flight.Count > 0)
                {
                    return View(flight);
                }
            }
            return View();
        }



        public ActionResult Update(string ID)
        {
            int flightID = Convert.ToInt32(ID);
            List<Flight_bk> flight = db.Flight_bk.Where(x => x.ID ==  flightID ).ToList();
            if (flight.Count > 0)
            {
                @Response.Redirect($"~/Flight/Edit/{flight[0].ID}");
            }
            return View();
        }

        public ActionResult Delete(string ID)
        {
            Flight_bk myflight = db.Flight_bk.Find(Convert.ToInt32(ID));
            if (myflight != null)
            {
                db.Flight_bk.Remove(myflight);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(myflight);
        }


    }
}